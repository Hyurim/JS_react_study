import React from "react";

function About() {
  return (
    <>
      <h1>About</h1>
      <p>How am I?</p>
    </>
  );
}

export default About;
